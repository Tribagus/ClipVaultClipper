# ClipVault Clipper — Android source

Native Kotlin Android MVP.

## Included
- Pick a video from Android storage
- Preview with Media3 ExoPlayer
- Load direct HTTP(S) media-file URLs (MP4/WebM)
- Manual trim by start/end seconds
- Export MP4 using AndroidX Media3 Transformer
- Java/Kotlin JVM target 17
- GitHub Actions workflow to build a debug APK

## Not included yet
AI highlight detection, speech-to-text captions, face tracking, smart reframing, B-roll generation, and cloud processing are planned integrations, not working features in this MVP. Hybrid AI needs a backend server and API credentials; do not put secret API keys inside the APK.

YouTube/TikTok/Instagram page URLs are not downloaded. Use videos you own or are authorized to edit, or implement official authorized API access. The app currently accepts direct video-file URLs only.

Output is stored in the app-specific Movies folder. It is not automatically published to the public gallery in this version.

## Build from Android using GitHub
1. Create a GitHub repository (Private recommended).
2. Extract this ZIP on your phone.
3. Upload the *contents* of the `ClipVaultClipper` folder to the repository root, preserving all folders including `.github/workflows`.
4. Commit to branch `main`.
5. Open **Actions**. Run **Build ClipVault Clipper APK** if it did not start automatically.
6. Open the successful run and download artifact `ClipVault-debug-apk`.
7. Extract the artifact ZIP and install `app-debug.apk`.

## Requirements for local build
JDK 17, Android SDK 35, Gradle 8.9. Run `gradle assembleDebug`.
