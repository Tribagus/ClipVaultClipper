package com.clipvault.clipper

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Locale

@UnstableApi
class MainActivity : AppCompatActivity() {
    private lateinit var preview: PlayerView
    private lateinit var status: TextView
    private lateinit var url: EditText
    private lateinit var fromSec: EditText
    private lateinit var toSec: EditText
    private var selected: Uri? = null
    private var player: ExoPlayer? = null

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selected = uri
            url.setText(uri.toString())
            play(uri)
            message("Video siap. Atur waktu mulai/akhir lalu export.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setBackgroundColor(0xFF10111A.toInt())
        }
        scroll.addView(page)
        page.addView(text("CLIPVAULT", 13, 0xFF9A91FF.toInt(), true))
        page.addView(text("Clipper", 30, -1, true))
        page.addView(text("Turn long videos into short clips", 14, 0xFFB7B8C7.toInt(), false))
        page.addView(gap(14))
        preview = PlayerView(this).apply { useController = true; layoutParams = LinearLayout.LayoutParams(-1, dp(210)) }
        page.addView(preview)
        page.addView(gap(10))
        page.addView(button("Pilih video dari galeri") { picker.launch(arrayOf("video/*")) })
        page.addView(gap(8))
        page.addView(text("Atau URL file video langsung (MP4/WebM)", 13, -1, true))
        url = EditText(this).apply {
            hint = "https://example.com/video.mp4"; setSingleLine(true)
            setTextColor(-1); setHintTextColor(0xFF888A9B.toInt())
            setPadding(dp(12), 0, dp(12), 0); setBackgroundColor(0xFF222433.toInt())
        }
        page.addView(url, LinearLayout.LayoutParams(-1, dp(52)))
        page.addView(gap(8))
        page.addView(button("Muat URL langsung") { loadUrl() })
        page.addView(gap(14))
        page.addView(text("Potong klip (detik)", 15, -1, true))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fromSec = numberField("Mulai", "0")
        toSec = numberField("Akhir", "30")
        row.addView(fromSec, LinearLayout.LayoutParams(0, dp(52), 1f))
        row.addView(gapHorizontal(10))
        row.addView(toSec, LinearLayout.LayoutParams(0, dp(52), 1f))
        page.addView(row)
        page.addView(gap(12))
        page.addView(button("Export Clip MP4") { export() })
        page.addView(gap(14))
        page.addView(text("AI Auto Clips • Auto Captions • Smart Reframe", 14, 0xFF9A91FF.toInt(), true))
        page.addView(text("Versi awal: pilih video, preview, potong manual, dan export lokal. Integrasi AI hybrid memerlukan server AI yang dikonfigurasi.", 13, 0xFFB7B8C7.toInt(), false))
        page.addView(gap(10))
        status = text("Pilih video untuk mulai.", 13, 0xFF19C6A7.toInt(), true)
        page.addView(status)
        page.addView(gap(12))
        page.addView(text("URL YouTube/TikTok/Instagram tidak diunduh dari halaman platform. Gunakan file yang kamu miliki/berizin atau integrasi API resmi.", 12, 0xFF9FA1B2.toInt(), false))
        setContentView(scroll)
    }

    private fun loadUrl() {
        val raw = url.text.toString().trim()
        val uri = Uri.parse(raw)
        if ((uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            message("Masukkan URL http/https yang valid."); return
        }
        val host = uri.host!!.lowercase(Locale.ROOT)
        if (host.contains("youtube.com") || host == "youtu.be" || host.contains("tiktok.com") || host.contains("instagram.com")) {
            message("Link platform bukan direct video. Gunakan file video berizin atau API resmi."); return
        }
        selected = uri
        play(uri)
        message("URL dimuat. Pastikan ini URL file video langsung.")
    }

    private fun play(uri: Uri) {
        player?.release()
        player = ExoPlayer.Builder(this).build().also {
            preview.player = it
            it.setMediaItem(MediaItem.fromUri(uri))
            it.prepare()
            it.playWhenReady = false
        }
    }

    private fun export() {
        val uri = selected ?: run { message("Pilih video atau muat URL dulu."); return }
        val start = fromSec.text.toString().toLongOrNull() ?: 0L
        val end = toSec.text.toString().toLongOrNull() ?: 0L
        if (start < 0 || end <= start) { message("Waktu akhir harus lebih besar dari waktu mulai."); return }
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val output = File(dir, "ClipVault_${System.currentTimeMillis()}.mp4")
        val clipped = MediaItem.Builder().setUri(uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(start * 1000).setEndPositionMs(end * 1000).build()
        ).build()
        val edited = EditedMediaItem.Builder(clipped).build()
        message("Sedang export… tunggu sampai selesai.")
        val transformer = Transformer.Builder(this).addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                message("Berhasil! File: ${output.absolutePath}")
            }
            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                message("Export gagal: ${exportException.message ?: "format tidak didukung"}")
            }
        }).build()
        try { transformer.start(edited, output.absolutePath) }
        catch (e: Exception) { message("Gagal memulai export: ${e.message}") }
    }

    private fun numberField(h: String, v: String) = EditText(this).apply {
        hint = h; setText(v); inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setTextColor(-1); setHintTextColor(0xFF888A9B.toInt())
        setPadding(dp(12), 0, dp(12), 0); setBackgroundColor(0xFF222433.toInt())
    }
    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setTextColor(-1)
        backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF6254E8.toInt())
        setOnClickListener { action() }
    }
    private fun text(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); setPadding(0, dp(3), 0, dp(3))
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun gap(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun gapHorizontal(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun message(s: String) { if (::status.isInitialized) status.text = s }
    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { preview.player = null; player?.release(); player = null; super.onDestroy() }
}
